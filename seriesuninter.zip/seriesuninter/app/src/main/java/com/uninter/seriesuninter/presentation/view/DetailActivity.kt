package com.uninter.seriesuninter.presentation.view

import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.uninter.seriesuninter.R
import com.uninter.seriesuninter.domain.entity.usecase.Serie

class DetailActivity : AppCompatActivity() {

    private lateinit var txtTitle: TextView
    private lateinit var txtDescriptor: TextView
    private lateinit var imgBack: ImageView
    private lateinit var imgPoster: ImageView
    private lateinit var btnFavorite: Button
    private val imageGetter = "https:///mZCq3ldk7hUIyDvfZIOvTrxPWYS.jpg"

    private var serie: Serie = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        serie = intent.getSerializableExtra("serie") as Serie
        bindView()

    }

    fun bindView(){
        txtTitle = findViewById(R.id.txtDetrailName)
        txtDescriptor = findViewById(R.id.txtDetailDescriptor)
        imgBack findViewById(R.id.imgDetailBack)
        imgPoster findViewById(R.id.imgDetailPoster)
        btnFavorite findViewById(R.id.btnDetailFavorite)

        serie?.let{ serie ->
            txtTitle.text = serie.name
            txtDescriptor.text = serie.overview

            Glide.with(this).load("").into(imgBack)
            Glide.with(this).load("").into(imgPoster)

        }

    }
}